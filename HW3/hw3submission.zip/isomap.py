import numpy as np
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import floyd_warshall
import numpy as np
import json
from matplotlib import pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from sklearn.feature_extraction import text
from sklearn.datasets import load_boston, load_diabetes, load_digits, load_breast_cancer, load_iris, load_wine
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, accuracy_score
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import floyd_warshall
import warnings

class Isomap(object):
    def __init__(self):  # No need to implement
        pass

    def pairwise_dist(self, x, y):  # [3 pts]
        """
        Args:
            x: N x D numpy array
            y: M x D numpy array
        Return:
                dist: N x M array, where dist2[i, j] is the euclidean distance between
                x[i, :] and y[j, :]
                """

        raise NotImplementedError

    def manifold_distance_matrix(self, x, K):  # [10 pts]
        """
        Args:
            x: N x D numpy array
        Return:
            dist_matrix: N x N numpy array, where dist_matrix[i, j] is the euclidean distance between points if j is in the neighborhood N(i)
            or comp_adj = shortest path distance if j is not in the neighborhood N(i).
        Hint: After creating your k-nearest weighted neighbors adjacency matrix, you can convert it to a sparse graph
        object csr_matrix (https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.csr_matrix.html) and utilize
        the pre-built Floyd-Warshall algorithm (https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.csgraph.floyd_warshall.html)
        to compute the manifold distance matrix.
        """


        newK=K+1

        dist_matrix = np.ones((x.shape[0], x.shape[0])) *1000
        for i in range(0,x.shape[0]):
            a=np.tile(x[i], (x.shape[0], 1))
            dis = np.linalg.norm(x - a, axis=1)
            #self.pairwise_dist(x,a)
            order = np.argsort(dis, axis=-1)
            dis.sort()
            dis2 = dis
            order = order[1:newK]
            dist = dis2[1:newK]
            dist_matrix[order, i] = dist
            dist_matrix[i, order] = dist


        np.fill_diagonal(dist_matrix, 0)

        dist_matrix = csr_matrix(dist_matrix)
        dist_matrix = floyd_warshall(dist_matrix)
        return dist_matrix

    def multidimensional_scaling(self, dist_matrix, d):  # [10 pts]
        """
        Args:
            dist_matrix: N x N numpy array, the manifold distance matrix
            d: integer, size of the new reduced feature space 
        Return:
            S: N x d numpy array, X embedding into new feature space.
        """

        #self.pairwise_dist(dist_matrix,d)
#        eVal, eVect = np.linalg.eig(dist_matrix)
        eig=np.linalg.eig(dist_matrix)
        i= dist_matrix+d
        i = eig[0].argsort()[::-1]
        vd = eig[0][i]
        reduv = eig[1][:, i]

        reduv2 =  reduv[:, 0:d]
        diag = np.diag(vd[0:d])


        return np.dot(reduv2,np.sqrt(diag))

    # you do not need to change this
    def __call__(self, data, K, d):
        # get the manifold distance matrix
        W = self.manifold_distance_matrix(data, K)
        # compute the multidimensional scaling embedding
        emb_X = self.multidimensional_scaling(W, d)
        return emb_X

# # HELPER CELL, DO NOT MODIFY
# # example MNIST data
# mnist = load_digits()
# proj = Isomap()(mnist.data, 10, 2)
# plt.scatter(proj[:, 0], proj[:, 1], c=mnist.target, cmap=plt.cm.get_cmap('jet', 10))
# plt.colorbar(ticks=range(10))
# plt.show()