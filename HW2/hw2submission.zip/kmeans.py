
from __future__ import absolute_import
from __future__ import print_function
from __future__ import division

import sys
import matplotlib
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import axes3d
from tqdm import tqdm
# Load image
import imageio

import numpy.linalg


# Set random seed so output is all same
np.random.seed(1)


class KMeans(object):

    def __init__(self):  # No need to implement
        pass

    def pairwise_dist(self, x, y):# [5 pts]
        """
        Args:
            x: N x D numpy array
            y: M x D numpy array
        Return:
                dist: N x M array, where dist2[i, j] is the euclidean distance between 
                x[i, :] and y[j, :]
                """

        #return np.sum((x[:,None] - y) ** 2, -1) ** 0.5


        #np.sum((x[None,:] - y[:, None])**2, -1)**0.5
        #return np.sum((x - y[:,None]) ** 2, -1) ** 0.5

        return np.linalg.norm(x[:, None] - y, axis=2)








    def _init_centers(self, points, K, **kwargs): # [5 pts]
        """
        Args:
            points: NxD numpy array, where N is # points and D is the dimensionality
            K: number of clusters
            kwargs: any additional arguments you want
        Return:
            centers: K x D numpy array, the centers.
        """
        center_indices = np.random.choice(points.shape[0],size=K, replace=False)
        centers = points[center_indices,:]
        return centers
    def _update_assignment(self, centers, points):  # [10 pts]
        """
        Args:
            centers: KxD numpy array, where K is the number of clusters, and D is the dimension
            points: NxD numpy array, the observations
        Return:
            cluster_idx: numpy array of length N, the cluster assignment for each point

        Hint: You could call pairwise_dist() function.
        """
        #z=[]
        #for x in points:
        #    z.append(np.argmin(sum([self.pairwise_dist(x,i) for i in centers])))

        #return np.argmin(self.pairwise_dist(centers,points),axis=1)
        return np.argmin(self.pairwise_dist(centers,points),axis=0)

        #raise NotImplementedError



    def _update_centers(self, old_centers, cluster_idx, points):  # [10 pts]
        """
        Args:
            old_centers: old centers KxD numpy array, where K is the number of clusters, and D is the dimension
            cluster_idx: numpy array of length N, the cluster assignment for each point
            points: NxD numpy array, the observations
        Return:
            centers: new centers, K x D numpy array, where K is the number of clusters, and D is the dimension.
        """
        # for x,y in zip(cluster_idx,points):
        #     print(x,y)
        s=[]
        for x in range (len(old_centers)):
            forones=np.where(cluster_idx == x)
            #points[forones]
            new_cluster = np.mean(points[forones],axis=0)
            s.append(new_cluster)
        y = np.array([np.array(xi) for xi in s])
        old_centers=y

        return old_centers
        #raise NotImplementedError

    def _get_loss(self, centers, cluster_idx, points):  # [5 pts]
        """
        Args:
            centers: KxD numpy array, where K is the number of clusters, and D is the dimension
            cluster_idx: numpy array of length N, the cluster assignment for each point
            points: NxD numpy array, the observations
        Return:
            loss: a single float number, which is the objective function of KMeans. 
        """
        loss = 0

        for i in range(len(centers)):
            cluster = points[cluster_idx == i]
            obj = np.sum((cluster - centers[i]) ** 2)
            loss += obj
        return loss
        #raise NotImplementedError

    def __call__(self, points, K, max_iters=100, abs_tol=1e-16, rel_tol=1e-16, verbose=False, **kwargs):
        """
        Args:
            points: NxD numpy array, where N is # points and D is the dimensionality
            K: number of clusters
            max_iters: maximum number of iterations (Hint: You could change it when debugging)
            abs_tol: convergence criteria w.r.t absolute change of loss
            rel_tol: convergence criteria w.r.t relative change of loss
            verbose: boolean to set whether method should print loss (Hint: helpful for debugging)
            kwargs: any additional arguments you want
        Return:
            cluster assignments: Nx1 int numpy array
            cluster centers: K x D numpy array, the centers
            loss: final loss value of the objective function of KMeans
        """
        centers = self._init_centers(points, K, **kwargs)
        
        for it in range(max_iters):
            cluster_idx = self._update_assignment(centers, points)
            centers = self._update_centers(centers, cluster_idx, points)
            loss = self._get_loss(centers, cluster_idx, points)
            K = centers.shape[0]


            if it:
                diff = np.abs(prev_loss - loss)
                if diff < abs_tol and diff / prev_loss < rel_tol:
                    break
            prev_loss = loss
            if verbose:
                print('iter %d, loss: %.4f' % (it, loss))
        return cluster_idx, centers, loss

    # def intra_cluster_dist(self,cluster_idx, data, labels):  # [4 pts]
    #     """
    #     Calculates the average distance from a point to other points within the same cluster
    #
    #     Args:
    #         cluster_idx: the cluster index (label) for which we want to find the intra cluster distance
    #         data: NxD numpy array, where N is # points and D is the dimensionality
    #         labels: 1D array of length N where each number indicates of cluster assignement for that point
    #     Return:
    #         intra_dist_cluster: 1D array where the i_th entry denotes the average distance from point i
    #                             in cluster denoted by cluster_idx to other points within the same cluster
    #     """
    #     list=[]
    #     n_list=[]
    #     s=[]
    #     # np.sum(np.sum(
    #     #     self.pairwise_dist(data[cluster_idx == x], data[cluster_idx == x]) / len(data[cluster_idx == x]))) / len(
    #     #     data[cluster_idx == x])
    #     for x in range(len(labels)):
    #         s.append(np.sum(np.sum(
    #             self.pairwise_dist(data[cluster_idx == x], data[cluster_idx == x]) / len(
    #                 data[cluster_idx == x]))) / len(
    #             data[cluster_idx == x]))
    #     # for x in range(len(labels)):
    #     #     for y in (data[cluster_idx==x]):
    #     #         list.append(np.sum(self.pairwise_dist(y,data[cluster_idx==x]))/len(data[cluster_idx==x]))
    #     #     avg=sum(list)/len(list)
    #     #     n_list.append(avg)
    #     #     list=[]
    #
    #     #print(list)
    #     return np.asarray(list)
        #raise NotImplementedError
    #
    # def inter_cluster_dist(self,cluster_idx, data, labels):  # [4 pts]
    #     """
    #     Calculates the average distance from one cluster to the nearest cluster
    #     Args:
    #         cluster_idx: the cluster index (label) for which we want to find the intra cluster distance
    #         data: NxD numpy array, where N is # points and D is the dimensionality
    #         labels: 1D array of length N where each number indicates of cluster assignement for that point
    #     Return:
    #         inter_dist_cluster: 1D array where the i-th entry denotes the average distance from point i in cluster
    #                             denoted by cluster_idx to the nearest neighboring cluster
    #     """
    #     for x in range(1,len(labels)):
    #         sdf=np.sum(self.pairwise_dist(data[cluster_idx==x-1][0],data[cluster_idx==x][0]))/len(data[cluster_idx==x-1])
    #
    #     #raise NotImplementedError

    # def silhouette_coefficient(data, labels):  # [2 pts]
    #     """
    #     Finds the silhouette coefficient of the current cluster assignment
    #
    #     Args:
    #         data: NxD numpy array, where N is # points and D is the dimensionality
    #         labels: 1D array of length N where each number indicates of cluster assignement for that point
    #     Return:
    #         silhouette_coefficient: Silhouette coefficient of the current cluster assignment
    #     """
    #     raise NotImplementedError
    #
    
    def find_optimal_num_clusters(self, data, max_K=15):  # [10 pts]
        """Plots loss values for different number of clusters in K-Means

        Args:
            image: input image of shape(H, W, 3)
            max_K: number of clusters
        Return:
            None (plot loss values against number of clusters)
        """
        # r = data.shape[0]
        # c = data.shape[1]
        # ch = data.shape[2]
        #
        # data = data.reshape(r * c, ch)
        loss_set=[]
        loss_yet=0
        for x in range (1,max_K):

            cluster_idx, centers, loss = self.__call__(data, x)


            loss_set.append(loss)
        return loss_set

        # plt.plot(loss_set)
        # plt.ylabel('Loss value')
        # plt.xlabel('K value')
        # plt.show()
        # #plt.imshow(updated_image_values)
        #plt.show()
            #self.__call__(data,K=x)

            #pass
        #raise NotImplementedError


    #raise NotImplementedError


def intra_cluster_dist(cluster_idx, data, labels):  # [4 pts]
    """
    Calculates the average distance from a point to other points within the same cluster

    Args:
        cluster_idx: the cluster index (label) for which we want to find the intra cluster distance
        data: NxD numpy array, where N is # points and D is the dimensionality
        labels: 1D array of length N where each number indicates of cluster assignement for that point
    Return:
        intra_dist_cluster: 1D array where the i_th entry denotes the average distance from point i
                            in cluster denoted by cluster_idx to other points within the same cluster
    """


    def pairwise_dist( x, y):  # [5 pts]
        """
        Args:
            x: N x D numpy array
            y: M x D numpy array
        Return:
                dist: N x M array, where dist2[i, j] is the euclidean distance between
                x[i, :] and y[j, :]
                """
        #return np.sum((x[None, :] - y[:, None]) ** 2, -1) ** 0.5

        return  np.linalg.norm(x[:, None] - y, axis=2)

    def pairwise_dist2( x, y):  # [5 pts]
        """
        Args:
            x: N x D numpy array
            y: M x D numpy array
        Return:
                dist: N x M array, where dist2[i, j] is the euclidean distance between
                x[i, :] and y[j, :]
                """
        return np.sum((x[:,None] - y) ** 2, -1) ** 0.5

    clid = data[labels == cluster_idx]

    return np.sum(pairwise_dist(clid,clid)/(len(clid)-1),axis=0)



def inter_cluster_dist23( cluster_idx, data, labels):  # [4 pts]
    """
    Calculates the average distance from one cluster to the nearest cluster
    Args:
        cluster_idx: the cluster index (label) for which we want to find the intra cluster distance
        data: NxD numpy array, where N is # points and D is the dimensionality
        labels: 1D array of length N where each number indicates of cluster assignement for that point
    Return:
        inter_dist_cluster: 1D array where the i-th entry denotes the average distance from point i in cluster
                            denoted by cluster_idx to the nearest neighboring cluster
    """

    def pairwise_dist(x, y):  # [5 pts]
        """
        Args:
            x: N x D numpy array
            y: M x D numpy array
        Return:sum(np.sum(pairwise_dist(clid1,valu),axis=1) / (len(clid1)))
                dist: N x M array, where dist2[i, j] is the euclidean distance between
                x[i, :] and y[j, :]
                """
        return np.sum((x[:, None] - y) ** 2, -1) ** 0.5



    dict={}
    clid1 = data[labels == cluster_idx]
    lists=[]

    for x in list(np.unique(labels)):
        if x==cluster_idx:
            continue
        clid2=data[labels==x]

        dict[x]=np.sum(np.sum(pairwise_dist(clid1,clid2),axis=1)/ (len(clid1)))
    smallest_idx=min(dict, key=dict.get)
    smallest_val=list(sorted(dict.values()))[-1]
    smallest_idx=list(dict.keys())[list(dict.values()).index(smallest_val)]
    print(smallest_idx)
    clid1=data[labels == cluster_idx]
    clid2=data[labels == smallest_idx]
    for x in clid1:
#        print (x)
        print(np.sum(pairwise_dist(x[None],clid2)/ (len(clid1)),axis=1))
        lists.append(np.sum(pairwise_dist(x[None],clid2)/ (len(clid1)),axis=1))
    #final = np.sum(pairwise_dist(clid1,clid2)/ (len(clid1)),axis=1)


    final=np.asarray(lists)
    return final


def inter_cluster_dist( cluster_idx, data, labels):  # [4 pts]
    """
    Calculates the average distance from one cluster to the nearest cluster
    Args:
        cluster_idx: the cluster index (label) for which we want to find the intra cluster distance
        data: NxD numpy array, where N is # points and D is the dimensionality
        labels: 1D array of length N where each number indicates of cluster assignement for that point
    Return:
        inter_dist_cluster: 1D array where the i-th entry denotes the average distance from point i in cluster
                            denoted by cluster_idx to the nearest neighboring cluster
    """

    def pairwise_dist2(x, y):  # [5 pts]
        """
        Args:
            x: N x D numpy array
            y: M x D numpy array
        Return:sum(np.sum(pairwise_dist(clid1,valu),axis=1) / (len(clid1)))
                dist: N x M array, where dist2[i, j] is the euclidean distance between
                x[i, :] and y[j, :]
                """
        return np.sum((x[:, None] - y) ** 2, -1) ** 0.5
    def pairwise_dist( x, y):  # [5 pts]
        """
        Args:
            x: N x D numpy array
            y: M x D numpy array
        Return:
                dist: N x M array, where dist2[i, j] is the euclidean distance between
                x[i, :] and y[j, :]
                """
        #return np.sum((x[None, :] - y[:, None]) ** 2, -1) ** 0.5

        return  np.linalg.norm(x[:, None] - y, axis=2)
    final=1
    listt=[]
    final_list=[]
    for pt in data[labels==cluster_idx]:

        for k in list(np.unique(labels)):
            if k!=cluster_idx:
                #listt.append(sum(pairwise_dist(pt[None], data[labels == k])) / len(data[labels==cluster_idx]))
                listt.append(sum(sum(pairwise_dist(pt[None], data[labels == k])) / len(data[labels==k])))

        final_list.append(min(listt))
        listt=[]
                #print(k)






    return np.asarray(final_list)


def silhouette_coefficient(data, labels):  # [2 pts]
    """
    Finds the silhouette coefficient of the current cluster assignment

    Args:
        data: NxD numpy array, where N is # points and D is the dimensionality
        labels: 1D array of length N where each number indicates of cluster assignement for that point
    Return:
        silhouette_coefficient: Silhouette coefficient of the current cluster assignment
    """
    #intra_cluster_dist(np.unique(labels), data, labels)
    listt=[]
    for x in range(len(np.unique(labels))):


        intra=intra_cluster_dist(x,data,labels)

        inter= inter_cluster_dist(x,data,labels)
        s_i= (inter-intra) / (np.amax((inter, intra), axis=0))
        listt.append(s_i)
    f=np.hstack((listt[0], listt[1]))

    return sum(f)/len(f)
    #raise NotImplementedError

def image_to_matrix(image_file, grays=False):
    """
    Convert .png image to matrix
    of values.
    params:
    image_file = str
    grays = Boolean
    returns:
    img = (color) np.ndarray[np.ndarray[np.ndarray[float]]]
    or (grayscale) np.ndarray[np.ndarray[float]]
    """
    img = plt.imread(image_file)
    # in case of transparency values
    if len(img.shape) == 3 and img.shape[2] > 3:
        height, width, depth = img.shape
        new_img = np.zeros([height, width, 3])
        for r in range(height):
            for c in range(width):
                new_img[r, c, :] = img[r, c, 0:3]
        img = np.copy(new_img)
    if grays and len(img.shape) == 3:
        height, width = img.shape[0:2]
        new_img = np.zeros([height, width])
        for r in range(height):
            for c in range(width):
                new_img[r, c] = img[r, c, 0]
        img = new_img
    return img